<?php $__env->startSection('title','Argo show movie'); ?>

<?php $__env->startSection('content'); ?>

<h3>This is the new content</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/cursoApp/resources/views/movie/show.blade.php ENDPATH**/ ?>