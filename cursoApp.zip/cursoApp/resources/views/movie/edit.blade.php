@extends('app.base')

@section('title','Argo edit movie')

@section('content')

<h3>This is the new content</h3>
@endsection