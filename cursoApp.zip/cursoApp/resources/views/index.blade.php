@extends('app.base')

@section('title','Argo Second Title')

@section('content')

<h3>This is the new content</h3>
@endsection