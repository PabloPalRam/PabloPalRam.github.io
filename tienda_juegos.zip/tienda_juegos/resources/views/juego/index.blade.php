@extends('app.base')

@section('title', 'Lista de videojuegos')

@section('content')

<div class="table-responsive small">
    <table class="table table-striped table-sm">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">nombre</th>
          <th scope="col">pais de origen</th>
          <th scope="col">año</th>
          <th scope="col">genero</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        @foreach($juegos as $juego)
            <tr>
                <td>{{ $juego->id }}</td>
                <td>{{ $juego->name }}</td>
                <td>{{ $juego->country }}</td>
                <td>{{ $juego->year }}</td>
                <td>{{ $juego->genre }}</td>
                <td>
                    <a class="btn-primary btn" href="{{ url('juego/' . $juego->id) }}">mostrar</a>
                    <a class="btn-danger btn" href="{{ url('juego/' . $juego->id . '/edit') }}">editar</a>
                    <form data-juego="{{ $juego->name }}" class="formDelete" action="{{ url('juego/' . $juego->id) }}" method="post" style="display: inline-block">
                      @csrf
                      @method('delete')
                      <button type="submit" class="btn btn-warning">borrar</button>
                    </form>
                </td>
            </tr>
        @endforeach
      </tbody>
    </table>
    <a class="btn-info btn" href="{{ url('juego/create') }}">crear</a>
</div>

<script>
  const forms = document.querySelectorAll(".formDelete");
  forms.forEach(function(form) {
      form.onsubmit = (event) => {
        return confirm('Seguro que quieres borrar ' + event.target.dataset.juego + '?');
      };
  });
</script>
@endsection
