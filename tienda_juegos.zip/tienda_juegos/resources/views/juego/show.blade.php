@extends('app.base')

@section('title', 'Lista de videojuegos')

@section('content')
<div class="table-responsive small">
    <table class="table table-striped table-sm">
        <tbody>
            <tr>
                <td>#</td>
                <td>{{ $juego->id }}</td>
            </tr>
            <tr>
                <td>Nombre</td>
                <td>{{ $juego->name }}</td>
            </tr>
            <tr>
                <td>Pais</td>
                <td>{{ $juego->country }}</td>
            </tr>
            <tr>
                <td>Año</td>
                <td>{{ $juego->year }}</td>
            </tr>
            <tr>
                <td>Genero</td>
                <td>{{ $juego->genre }}</td>
            </tr>
        </tbody>
    </table>
</div>
@endsection 