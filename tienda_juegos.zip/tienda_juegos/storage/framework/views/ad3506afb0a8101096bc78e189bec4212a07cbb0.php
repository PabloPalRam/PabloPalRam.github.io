<?php $__env->startSection('title','crear videojuego'); ?>

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html>
<head>
    <title>juegos</title>
</head>
<body>

<symbol id="juego" viewBox="0 0 16 16">
  <path d="M0 1a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1zm4 0v6h8V1H4zm8 8H4v6h8V9zM1 1v2h2V1H1zm2 3H1v2h2V4zM1 7v2h2V7H1zm2 3H1v2h2v-2zm-2 3v2h2v-2H1zM15 1h-2v2h2V1zm-2 3v2h2V4h-2zm2 3h-2v2h2V7zm-2 3v2h2v-2h-2zm2 3h-2v2h2v-2z"/>
</symbol>


<form action="<?php echo e(url('juego')); ?>" method="post">

    <!-- Solución de error por CSRF -->
    <!--<input type="hidden" name="_method" value="post">-->
    <!--<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">-->
    <?php echo csrf_field(); ?>

    <!-- Inputs del formulario -->

    <div class="mb-3">

        <label for="name" class="form-label">titulo del juego</label>

        <input type="text" class="form-control" id="name" name="name" maxlength="60" required value="<?php echo e(old('name')); ?>">

    </div>

    <div class="mb-3">

        <label for="country" class="form-label">Pais de origen</label>

        <input type="text" class="form-control" id="country" name="country" maxlength="50" required value="<?php echo e(old('country')); ?>">

    </div>

    <div class="mb-3">

        <label for="year" class="form-label">Año</label>

        <input type="number" class="form-control" id="year" name="year" step="1" min="1" max="9999" required value="<?php echo e(old('year')); ?>">

    </div>

    <div class="mb-3">

        <label for="genre" class="form-label">Genero</label>

        <input type="text" class="form-control" id="genre" name="genre" maxlength="50" value="<?php echo e(old('genre')); ?>">

    </div>

    <button type="submit" class="btn btn-success">Insertar</button>

</form>
</body>
</html>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laraveles/tienda_juegos/resources/views/juego/create.blade.php ENDPATH**/ ?>